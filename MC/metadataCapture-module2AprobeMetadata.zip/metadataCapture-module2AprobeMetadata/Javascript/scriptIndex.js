$(document).ready(function(){
			$("#msg_error").fadeOut(10000);
		});